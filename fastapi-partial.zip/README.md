# DermaScan Backend (FastAPI)

## 실행 방법
```bash
uvicorn main:app --reload
```

## 이미지 업로드 API
- POST /upload-image
- form-data로 이미지 파일 업로드